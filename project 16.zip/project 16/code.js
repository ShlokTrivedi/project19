var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["a6870703-0124-47f7-acff-dbe905f5014c","5ce44e39-12ac-4a66-88cf-a87a0ed6a180","33841f90-7a53-4346-b956-e51d1961959b","11a1d3f4-7895-4386-8cd4-13843a38118f","36bced41-1a58-4520-882b-2069a5cbe2d3"],"propsByKey":{"a6870703-0124-47f7-acff-dbe905f5014c":{"name":"monkey","sourceUrl":null,"frameSize":{"x":560,"y":614},"frameCount":10,"looping":true,"frameDelay":4,"version":"IDwDeepWuoD1v0fxUV3MyIZ_1yhVsYdm","loadedFromSource":true,"saved":true,"sourceSize":{"x":1680,"y":1842},"rootRelativePath":"assets/a6870703-0124-47f7-acff-dbe905f5014c.png"},"5ce44e39-12ac-4a66-88cf-a87a0ed6a180":{"name":"Banana","sourceUrl":null,"frameSize":{"x":1080,"y":1080},"frameCount":1,"looping":true,"frameDelay":12,"version":"1OwYXdJGJMF9FdPyAPYekZUqKommFoEN","loadedFromSource":true,"saved":true,"sourceSize":{"x":1080,"y":1080},"rootRelativePath":"assets/5ce44e39-12ac-4a66-88cf-a87a0ed6a180.png"},"33841f90-7a53-4346-b956-e51d1961959b":{"name":"Stone","sourceUrl":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"0IB20foJ6h3S09sW8mn5ZN7SFlW55Tkn","loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/0Pmc2UypwJxUUUBBxMOOYmiSvh97BJLRo_BQZbjyEto/33841f90-7a53-4346-b956-e51d1961959b.png"},"11a1d3f4-7895-4386-8cd4-13843a38118f":{"name":"textGameOver_1","sourceUrl":"assets/api/v1/animation-library/gamelab/jlwUdmDfQ.Fl8uZni7e_c3sVaNJCXBYL/category_gameplay/textGameOver.png","frameSize":{"x":412,"y":78},"frameCount":1,"looping":true,"frameDelay":2,"version":"jlwUdmDfQ.Fl8uZni7e_c3sVaNJCXBYL","loadedFromSource":true,"saved":true,"sourceSize":{"x":412,"y":78},"rootRelativePath":"assets/api/v1/animation-library/gamelab/jlwUdmDfQ.Fl8uZni7e_c3sVaNJCXBYL/category_gameplay/textGameOver.png"},"36bced41-1a58-4520-882b-2069a5cbe2d3":{"name":"restart","sourceUrl":null,"frameSize":{"x":64,"y":64},"frameCount":1,"looping":true,"frameDelay":12,"version":"wKMyn_2uU58xaf7woFVVeyeYavpSpA9H","loadedFromSource":true,"saved":true,"sourceSize":{"x":64,"y":64},"rootRelativePath":"assets/36bced41-1a58-4520-882b-2069a5cbe2d3.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var PLAY = 1;
var END = 0;
var gameState = PLAY;

var player = createSprite(50, 305);
player.scale=0.1;

var finish=createSprite(200,200);
finish.setAnimation("textGameOver_1");
finish.scale=0.5;

var restart=createSprite(190,265,10,10);
restart.setAnimation("restart");

var ground = createSprite(200, 350,400,10);
ground.shapeColor="black";

var FoodGroup=createGroup();
var EnemyGroup=createGroup();

var survivalTime=0;

function draw(){
  
  background("white");
 
  player.collide(ground);
  
  if (gameState === PLAY){
    
    restart.visible=false;
    finish.visible=false;
  
    player.setAnimation("monkey");
    
    spawnBananas();
    spawnEnemies();
    
    if(keyDown("space")&& player.y >= 305){
     player.velocityY=-18;
     }
     
    player.velocityY=player.velocityY+1;
     
    stroke("black");
    textSize(20);
    fill("black");
    survivalTime=Math.ceil(frameCount/frameRate());
    text("Score = "+survivalTime,295,30);
    
    if (player.isTouching(FoodGroup)){
      FoodGroup.destroyEach();
      survivalTime=survivalTime+10;
    }
     
    if(player.isTouching(EnemyGroup)){
       gameState=END;
     }
    
  }else if(gameState === END){
     
    stroke("black");
    textSize(20);
    fill("black");
    text("Survival Time : "+survivalTime,100,50);
    
    EnemyGroup.destroyEach();
    FoodGroup.destroyEach();
    
    EnemyGroup.setVelocityXEach(0);
    FoodGroup.setVelocityXEach(0);
    
    restart.visible=true;
    finish.visible=true;
    
    player.setAnimation("monkey_copy_1");
    
    if(mousePressedOver(restart)){
      gameState=PLAY;
    }
  }
  
  drawSprites();
}

function spawnBananas(){
  
  if (frameCount % 80 === 0) {
     
    var banana = createSprite(600,250,40,10);
    banana.y = random(120,200);    
    banana.velocityX = -5;
    
    //assign lifetime to the variable
    banana.lifetime = 500;
    player.depth = banana.depth + 1;
    
    //add image of banana
     banana.setAnimation("Banana");
    banana.scale=0.05;
    
    
    
    //add each banana to the group
    FoodGroup.add(banana);
    
   }
}

function spawnEnemies(){
  
  if(World.frameCount%80===0){
    
    var obstacle = createSprite(430, 318);

    
    obstacle.setAnimation("Stone");
    obstacle.scale=0.15;
    
    obstacle.lifetime=500;
    
    obstacle.velocityX=-5;
    
    obstacle.setCollider("circle",0,0,130);

    EnemyGroup.add(obstacle);
    
 }
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
